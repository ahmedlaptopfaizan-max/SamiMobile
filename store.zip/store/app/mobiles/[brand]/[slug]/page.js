import { notFound } from "next/navigation";
import { db, rs, eff } from "@/lib/db";
import Checkout from "./Checkout";
const get = (slug) => db.product.findUnique({ where: { slug }, include: { brand: true } });
export async function generateMetadata({ params }) { const p = await get(params.slug); if (!p) return {};
  return { title: `${p.name} Price in Pakistan`, description: `Buy ${p.name} at ${rs(eff(p))} with Cash on Delivery.`, alternates: { canonical: `/mobiles/${p.brand.slug}/${p.slug}` }, openGraph: { images: p.images.slice(0, 1) } }; }
export default async function Page({ params }) {
  const p = await get(params.slug); if (!p || !p.published) notFound();
  const ld = { "@context": "https://schema.org", "@type": "Product", name: p.name, image: p.images, brand: { "@type": "Brand", name: p.brand.name }, description: p.description,
    offers: { "@type": "Offer", priceCurrency: "PKR", price: eff(p), availability: p.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock" } };
  const specs = [["Brand", p.brand.name], ["RAM", p.ram + " GB"], ["Storage", p.storage + " GB"], ["Battery", p.battery + " mAh"], ["Camera", p.camera], ["Network", p.network], ["PTA", p.pta ? "Approved" : "Non-PTA"]];
  return (<><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
    <nav><a href="/">Home</a> › <a href="/mobiles">Mobiles</a> › <a href={`/mobiles?brand=${p.brand.slug}`}>{p.brand.name}</a></nav>
    <h1>{p.name}</h1>{p.isDemo && <p><small>Demo product — verify price &amp; specs.</small></p>}
    <img src={p.images[0] || "/placeholder.svg"} alt={p.name} style={{ maxWidth: 320 }} />
    <h2 className="price">{rs(eff(p))}</h2><p>{p.description}</p>
    <h2>Specifications</h2><table>{specs.map(([k, v]) => <tr key={k}><th align="left">{k}</th><td>{v}</td></tr>)}</table>
    <h2>Order (Cash on Delivery)</h2>{p.stock > 0 ? <Checkout product={{ id: p.id, colors: p.colors, price: eff(p) }} delivery={Number(process.env.DELIVERY_FEE ?? 250)} /> : <p>Out of stock</p>}</>);
}

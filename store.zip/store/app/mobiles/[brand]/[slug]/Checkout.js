"use client";
import { useState, useRef } from "react";
export default function Checkout({ product, delivery }) {
  const key = useRef(crypto.randomUUID()); const [busy, setBusy] = useState(false); const [err, setErr] = useState(""); const [qty, setQty] = useState(1);
  async function submit(e) { e.preventDefault(); if (busy) return; setBusy(true); setErr("");
    const f = Object.fromEntries(new FormData(e.target)); const body = { ...f, idemKey: key.current, productId: product.id, qty };
    const r = await fetch("/api/order", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const j = await r.json();
    if (r.ok) location.href = `/order/${j.orderNo}?p=${encodeURIComponent(f.phone)}`; else { setErr(j.error); setBusy(false); } }
  return (<form className="f" onSubmit={submit}>
    {product.colors.length > 0 && <select name="color">{product.colors.map(c => <option key={c}>{c}</option>)}</select>}
    <label>Qty <input type="number" min="1" max="5" value={qty} onChange={e => setQty(+e.target.value || 1)} /></label>
    <input name="name" placeholder="Full name" required /><input name="phone" placeholder="Mobile (03XXXXXXXXX)" required /><input name="altPhone" placeholder="Alternate mobile (optional)" />
    <input name="email" type="email" placeholder="Email (optional)" /><select name="province" required>{["Punjab", "Sindh", "KPK", "Balochistan", "Islamabad", "AJK", "Gilgit-Baltistan"].map(x => <option key={x}>{x}</option>)}</select>
    <input name="city" placeholder="City" required /><textarea name="address" placeholder="Complete delivery address" required /><input name="landmark" placeholder="Nearby landmark (optional)" />
    <textarea name="notes" placeholder="Order notes (optional)" /><input className="hp" name="website" tabIndex="-1" autoComplete="off" />
    <p>Subtotal Rs. {(product.price * qty).toLocaleString()} + Delivery Rs. {delivery} = <b>Rs. {(product.price * qty + delivery).toLocaleString()}</b></p>
    {err && <p style={{ color: "red" }}>{err}</p>}<button className="btn" disabled={busy}>{busy ? "Placing…" : "Confirm Order (COD)"}</button></form>);
}

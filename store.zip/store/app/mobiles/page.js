import { db } from "@/lib/db";
import Card from "@/lib/Card";
export const metadata = { title: "Mobile Phones Price in Pakistan", alternates: { canonical: "/mobiles" } };
export default async function List({ searchParams: s }) {
  const w = { published: true, AND: [] };
  if (s.brand) w.brand = { slug: s.brand };
  if (s.ram) w.ram = +s.ram;
  if (s.storage) w.storage = +s.storage;
  if (s.network) w.network = s.network;
  if (s.pta) w.pta = s.pta === "1";
  if (s.stock) w.stock = { gt: 0 };
  if (s.min || s.max) w.AND.push({ OR: [{ salePrice: { gte: +(s.min || 0), lte: +(s.max || 9e7) } }, { salePrice: null, price: { gte: +(s.min || 0), lte: +(s.max || 9e7) } }] });
  if (s.q) w.AND.push({ OR: [{ name: { contains: s.q, mode: "insensitive" } }, { brand: { name: { contains: s.q, mode: "insensitive" } } }, { description: { contains: s.q, mode: "insensitive" } }] });
  const order = { low: { price: "asc" }, high: { price: "desc" }, popular: { stock: "desc" } }[s.sort] || { createdAt: "desc" };
  const [items, brands] = await Promise.all([db.product.findMany({ where: w, orderBy: order, include: { brand: true } }), db.brand.findMany()]);
  return (<><h1>Mobile Phones in Pakistan</h1>
    <form className="row"><select name="brand" defaultValue={s.brand || ""}><option value="">All brands</option>{brands.map(b => <option key={b.id} value={b.slug}>{b.name}</option>)}</select>
      <select name="ram" defaultValue={s.ram || ""}><option value="">RAM</option>{[4, 6, 8, 12, 16].map(r => <option key={r}>{r}</option>)}</select>
      <select name="storage" defaultValue={s.storage || ""}><option value="">Storage</option>{[64, 128, 256, 512].map(r => <option key={r}>{r}</option>)}</select>
      <select name="network" defaultValue={s.network || ""}><option value="">4G/5G</option><option>4G</option><option>5G</option></select>
      <input name="min" placeholder="Min Rs." defaultValue={s.min} size="7" /><input name="max" placeholder="Max Rs." defaultValue={s.max} size="7" />
      <select name="sort" defaultValue={s.sort || ""}><option value="">Latest</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option><option value="popular">Popular</option></select>
      <button className="btn">Filter</button></form>
    <p>{items.length} phones</p><div className="grid">{items.map(p => <Card key={p.id} p={p} />)}</div></>);
}

import { db } from "@/lib/db";
export default async function s() { const b = process.env.SITE_URL || "http://localhost:3000";
  const ps = await db.product.findMany({ where: { published: true }, include: { brand: true } });
  return [{ url: b }, { url: b + "/mobiles" }, ...ps.map(p => ({ url: `${b}/mobiles/${p.brand.slug}/${p.slug}`, lastModified: p.createdAt }))]; }

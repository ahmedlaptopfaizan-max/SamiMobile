import { db, rs } from "@/lib/db";
export const metadata = { robots: { index: false } };
export default async function O({ params, searchParams }) {
  const o = await db.order.findUnique({ where: { id: Number(params.no) - 10000 } });
  if (!o || o.phone !== searchParams.p) return <p>Order not found. Check your order number and phone.</p>;
  return (<><h1>Thank you, {o.name}!</h1><p>Order <b>#{o.id + 10000}</b> — Status: <b>{o.status}</b></p><p>{o.productName} × {o.qty} — Total {rs(o.total)} (Cash on Delivery)</p></>);
}

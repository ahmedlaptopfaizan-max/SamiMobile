import { z } from "zod";
import { db, eff } from "@/lib/db";
import { sendOrderMail } from "@/lib/mail";
const S = z.object({ idemKey: z.string().min(8), productId: z.number().int(), qty: z.number().int().min(1).max(5), color: z.string().optional(),
  name: z.string().min(2), phone: z.string().regex(/^(\+92|0)3\d{9}$/), altPhone: z.string().optional(), email: z.string().email().optional().or(z.literal("")),
  province: z.string().min(2), city: z.string().min(2), address: z.string().min(10), landmark: z.string().optional(), notes: z.string().optional(), website: z.string().max(0).optional() });
export async function POST(req) {
  const p = S.safeParse(await req.json());
  if (!p.success) return Response.json({ error: "Please check your details." }, { status: 400 });
  const d = p.data;
  const dup = await db.order.findUnique({ where: { idemKey: d.idemKey } });
  if (dup) return Response.json({ orderNo: dup.id + 10000 });
  const delivery = Number(process.env.DELIVERY_FEE ?? 250);
  let order;
  try {
    order = await db.$transaction(async (tx) => {
      const prod = await tx.product.findUnique({ where: { id: d.productId } });
      if (!prod || !prod.published || prod.stock < d.qty) throw new Error("STOCK");
      await tx.product.update({ where: { id: prod.id }, data: { stock: { decrement: d.qty } } });
      const { website, ...rest } = d;
      const unit = eff(prod);
      return tx.order.create({ data: { ...rest, productName: prod.name, unitPrice: unit, delivery, total: unit * d.qty + delivery } });
    });
  } catch (e) { return Response.json({ error: e.message === "STOCK" ? "Sorry, this item is out of stock." : "Could not place order." }, { status: 400 }); }
  try { await sendOrderMail(order); await db.order.update({ where: { id: order.id }, data: { emailSent: true } }); }
  catch (e) { await db.order.update({ where: { id: order.id }, data: { emailError: String(e.message).slice(0, 300) } }); console.error("Order email failed", e); }
  return Response.json({ orderNo: order.id + 10000 });
}

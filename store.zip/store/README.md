# Mobile Store (Phase 1)
1. Create a free Postgres DB (Neon or Supabase) and copy its URL.
2. Push this folder to GitHub, import in Vercel, add env vars from `.env.example`.
3. Gmail: enable 2-Step Verification, create an App Password, put it in GMAIL_APP_PASSWORD.
4. Locally once: `npm i && npx prisma db push && npm run seed` (with DATABASE_URL set).
5. Deploy. Place a test order and confirm the email arrives.
Not yet built: /admin, blog, tracking page, image uploads, price-range pages.
